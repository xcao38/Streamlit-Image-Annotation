IS_RELEASE = True

from .Detection import detection
